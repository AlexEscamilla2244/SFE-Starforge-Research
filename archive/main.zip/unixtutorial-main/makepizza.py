#!/usr/bin/ env python

import numpy as np

print('What kind of pizza is your favorite?')
